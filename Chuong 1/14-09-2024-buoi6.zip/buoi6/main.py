
#? Pygame : cung cấp tính năng xây dựng ứng dụng game
#? B1: Cài đặt thư viện
import pygame #thư viện chứa các tính năng của game
import sys #Thư viện của hệ thống (hệ điều hành của máy tính)

#? B2: Khởi tạo game
pygame.init() 

#? B3: Tạo cửa sổ game
#tạo biến
SCREEN_WIDTH = 1080
SCREEN_HEIGHT = 720
#Sử dụng biến
# (SCREEN_WIDTH, SCREEN_HEIGHT), (x,y) => tuple
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

#Tên của cửa sổ
pygame.display.set_caption("Superman")

#? B5 Xét font và kích thước chữ
    #?B5.1 Tạo và xét font 1 lần
    # đường dẫn tương đối (vị trí bắt dầu main.py -> vị trí kết thúc - file font)
    # ./ : các file & folder cùng cấp
font_game = pygame.font.Font("./fonts/TechnoRaceItalic-eZRWe.otf", 32)

    #?B5.2  Tạo surface Text => render("nôi dung chữ",quy định nét chữ rõ hay không, màu chữ)
title_game = font_game.render("New Game", True, "Gold")
    #?B5.3: quy định tọa độ hiển thị surface Text  (x, y) => (width, height)
x_title_game = SCREEN_WIDTH // 2 - title_game.get_width() // 2
y_title_game = SCREEN_HEIGHT // 2 - title_game.get_height() // 2

line_height = 50
title_game2 = font_game.render("Introduce", True, "Gold")
x_title_game2 = SCREEN_WIDTH // 2 - title_game2.get_width() // 2
y_title_game2 = SCREEN_HEIGHT // 2 + line_height - title_game2.get_height() // 2


#? B4: Hiển thi cửa sổ 
running = True
while running:
    # load nhiều lần cửa sổ game để bắt các chuyển động và sự kiện trong game
    
    #?B5.4: Hiển thi text ở cửa sổ blit(surface, tọa độ)
    screen.blit(title_game, (x_title_game,y_title_game))
    screen.blit(title_game2, (x_title_game2,y_title_game2))

    # events: thao tác của user
    #? events = pygame.event.get() # phải học về list (array) 
    event = pygame.event.poll() # 1 sự kiện
    # chuyển running thành False để tắt game
    if event.type == pygame.QUIT:
        running = False
        
    pygame.display.flip() # Load lại màn hình 
        
#? Ngoài vòng lặp
pygame.quit()
sys.exit()



    
