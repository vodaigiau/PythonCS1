'''
    Do while (java, JavaScript, php, C#, python không có)
    + ít dùng
    + dễ hiểu
'''

