'''
 hàng động lặp lại
 điều kiện để tiếp tục hoặc dừng
 
 
'''

# Nhược điểm: code dài, khó chỉnh sửa
print("Hello Idol A")
print("Hello Idol A")
print("Hello Idol A")
print("Hello Idol A")
print("Hello Idol A")
print("Hello Idol A")
print("Hello Idol A")
print("Hello Idol")
print("Hello Idol")
print("Hello Idol")


# Vòng lặp (loop)
# ưu điểm: code ngắn, dễ chỉnh sửa
count = 1
while count <=20:
    print("Hello Idol B")
    count = count + 1

