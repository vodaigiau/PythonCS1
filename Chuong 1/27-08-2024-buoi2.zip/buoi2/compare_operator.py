
#? Toán tử so sánh
# vế trái  dấu so sánh   vế phải
# Kết quả của phép so sánh chỉ có 2 giá trị: True, False 
# Kiểu dữ liệu Boolean (True, False )

print("So sánh bằng: " ,5 == 5) #True
print("So sánh bằng: " ,5 == 6) #False
print("Lớn hơn: ", 5 > 3) #True
print("Lớn hơn: ", 3 > 4) #False
print("Bé hơn: ", 3 < 5) #True

print("lớn hơn hoặc bằng: ", 5 >= 4) #True
print("lớn hơn hoặc bằng: ", 5 >= 5) #True

# Dấu bằng
# '=' => gán giá trị
# '==' => so sánh

# Chuỗi: phép toán so sánh sẽ so sánh từng ký tự 
print("So sánh bằng: " ,'12' < '123') # 1 so sánh 1, 2 so sánh 2
print("So sánh bằng: " ,'13' < '123') #1 so sánh 1, 3 so sánh 2




# JS
# print("So sánh bằng: " ,5 == 5) => so sánh giá trị
# print("So sánh bằng: " ,5 === 5) => so sánh kiểu dữ liệu
