
#? Toán tử 

# +, -, *, /

print("Tổng: " ,5 + 10) #int cộng số
print("Hiệu: ", 10 - 5) #int
print("Tích: ", 5 * 10) #int
print("Thương: " ,10 / 5)#float
print("Thương chia không hết: " ,10 / 3)#float

print(10 // 3)#3 => làm tròn xuống
print(10 % 3)#1 => lấy phần dư
print(5 ** 2) #25 => Lấy lũy thừa (5 lũy thừa 2)

#? Kiểu string

print("Hello" + " CyberSoft") #String nối chuỗi
