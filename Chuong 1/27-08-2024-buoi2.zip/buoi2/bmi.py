#IPO
'''
Block Comment
Input:dữ liệu đầu vào
 + weight
 + height
Process:
    B1: Cho người dùng nhập 2 dữ liệu weight & height
    B2: Lập công thức
        C1: bmi = weight / (height * height)
        C2: bmi = weight / (height ** 2)
        C3: tính năng có sẵn (Function build-in)
            bmi = weight / pow(height, 2)
Output:
    bmi
'''

# B1
# weight = float(input("Nhập cân nặng: "))
# height = float(input("Nhập chiều cao: "))
weight = input("Nhập cân nặng: ")
height = input("Nhập chiều cao: ")

#B2: 
bmi = float(weight) / ( float(height) ** 2)

#B3:
print("Chỉ số BMI: ", bmi)


#Debug : hiểu được cách thực thi của từng dòng code => tìm được lý do lỗi code